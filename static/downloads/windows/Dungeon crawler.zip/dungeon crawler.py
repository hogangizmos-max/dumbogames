import pygame # type: ignore
import sys
import math
import random
import time
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()
def pyprint(message, scale, color, position, font):
    font = pygame.font.SysFont(font, scale)
    screen.blit(font.render(str(message), True, color), position)
def apyprint(message, scale, color, position, font, alpha=255):
    font = pygame.font.SysFont(font, scale)
    text_surface = font.render(str(message), True, color).convert_alpha()
    text_surface.set_alpha(alpha)
    screen.blit(text_surface, position)
guns = {
    "Pistol": {"type": "projectile", "rarity": "common", "speed": 200, "damage": 15, "cooldown": 0.3, "autoshoot": 1, "pelets": 1, "pelet spread": 0, "size": 3, "price": 0, "chance": 0, "pushback": 2, "personback": .5, "knockback": 2, "appearence": pygame.transform.scale(pygame.image.load("pistol.png").convert_alpha(),(90, 45)), "offset": [18, 25]},
    "Sniper": {"type": "projectile", "rarity": "common", "speed": 800, "damage": 100, "cooldown": 2, "autoshoot": 0, "pelets": 1, "pelet spread": 0, "size": 2, "price": 50, "chance": 6, "pushback": 30, "personback": 10, "knockback": 50, "appearence": pygame.transform.scale(pygame.image.load("pistol.png").convert_alpha(),(90, 45)), "offset": [18, 25]},
    "Assault Rifle": {"type": "projectile", "rarity": "common", "speed": 300, "damage": 20, "cooldown": 0.2, "autoshoot": 1, "pelets": 1, "pelet spread": 0, "size": 2, "price": 50, "chance": 5, "pushback": 1, "personback": 1, "knockback": 1, "appearence": pygame.transform.scale(pygame.image.load("assault rifle.png").convert_alpha(),(120, 60)), "offset": [18, 25]},
    "Bazooka": {"type": "projectile", "rarity": "common", "speed": 100, "damage": 50, "cooldown": 0.8, "autoshoot": 0, "pelets": 1, "pelet spread": 0, "size": 10, "price": 30, "chance": 10, "pushback": 8, "personback": 10, "knockback": 20, "appearence": pygame.transform.scale(pygame.image.load("bazooka.png").convert_alpha(),(120, 60)), "offset": [18, 25]},
    "Double Barrel Shotgun": {"type": "projectile", "rarity": "common", "speed": 200, "damage": 40, "cooldown": 0.8, "autoshoot": 0, "pelets": 2, "pelet spread": 15, "size": 5, "price": 100, "chance": 5, "pushback": 15, "personback": 20, "knockback": 20, "appearence": pygame.transform.scale(pygame.image.load("doublebarrel shotgun.png").convert_alpha(),(90, 45)), "offset": [18, 25]},
    "Automated Shotgun": {"type": "projectile", "rarity": "legendary", "speed": 130, "damage": 10, "cooldown": 0.4, "autoshoot": 1, "pelets": 7, "pelet spread": 15, "size": 3, "price": 200, "chance": 2, "pushback": 5, "personback": 15, "knockback": 10, "appearence": pygame.transform.scale(pygame.image.load("autoshotgun.png").convert_alpha(),(90, 45)), "offset": [30, 30]},
    "Flintlock Pistol": {"type": "projectile", "rarity": "legendary", "speed": 400, "damage": 70, "cooldown": 3.0, "autoshoot": 0, "pelets": 1, "pelet spread": 0, "size": 5, "price": 200, "chance": 2, "pushback": 30, "personback": 100, "knockback": 50, "appearence": pygame.transform.scale(pygame.image.load("Flintlock Pistol.png").convert_alpha(),(90, 45)), "offset": [18, 25]},
    "Katana": {"type": "melee", "rarity": "common", "multiplier": ["ediv", 2], "speed": .2, "damage": 60, "chance": 5, "swingrange": 200, "cooldown": .3, "autoshoot": 1, "price": 80, "personback": 0, "pushback": 0, "knockback": 15, "appearence": pygame.transform.scale(pygame.image.load("katana.png").convert_alpha(),(180.00, 75.00))},
    "Claymore": {"type": "melee", "rarity": "common", "multiplier": ["ediv", 2], "speed": .8, "damage": 200, "chance": 5, "swingrange": 500, "cooldown": .9, "autoshoot": 1, "price": 200, "personback": 5, "pushback": 3, "knockback": 30, "appearence": pygame.transform.scale(pygame.image.load("claymore.png").convert_alpha(),(180.00, 75.00))},
    "Great Claymore": {"type": "melee", "rarity": "legendary", "multiplier": ["ediv", 3], "speed": 1, "damage": 500, "chance": 2, "swingrange": 500, "cooldown": 3, "autoshoot": 1, "price": 200, "personback": 5, "pushback": 3, "knockback": 30, "appearence": pygame.transform.scale(pygame.image.load("claymore.png").convert_alpha(),(360.00, 150.00))},
    "Giant Claymore": {"type": "melee", "rarity": "divine", "multiplier": ["ediv", 3], "speed": 1, "damage": 1000, "chance": 1, "swingrange": 500, "cooldown": 1.5, "autoshoot": 1, "price": 200, "personback": 5, "pushback": 3, "knockback": 30, "appearence": pygame.transform.scale(pygame.image.load("claymore.png").convert_alpha(),(720.00, 300.00))},
    "sprayer": {"type": "projectile", "rarity": "common", "speed": 100, "damage": 1, "cooldown": 0.05, "autoshoot": 1, "pelets": 3, "pelet spread": 6, "size": 3, "price": 200, "chance": 5, "pushback": 5, "personback": 0, "knockback": 10, "appearence": pygame.transform.scale(pygame.image.load("autoshotgun.png").convert_alpha(),(90, 45)), "offset": [30, 30]},
    "flamesprayer": {"type": "projectile", "rarity": "legendary", "speed": 130, "damage": 1, "cooldown": 0.01, "autoshoot": 1, "pelets": 10, "pelet spread": 2, "size": 5, "price": 200, "chance": 2, "pushback": 5, "personback": 0, "knockback": 10, "appearence": pygame.transform.scale(pygame.image.load("autoshotgun.png").convert_alpha(),(90, 45)), "offset": [30, 30]},
    "Halo sprayer": {"type": "projectile", "rarity": "divine", "speed": 400, "damage": 2, "cooldown": 0.01, "autoshoot": 1, "pelets": 30, "pelet spread": 100, "size": 3, "price": 50, "chance": 1, "pushback": 30, "personback": 3, "knockback": 50, "appearence": pygame.transform.scale(pygame.image.load("pistol.png").convert_alpha(),(90, 45)), "offset": [18, 25]},
    "medkit": {"type": "heal", "rarity": "legendary", "time": 1, "chance": 2, "health": 40, "amount": 2, "appearence": pygame.transform.scale(pygame.image.load("medkit.png").convert_alpha(),(90, 45))}
}
inventory = {
    "gun": "gun1",
    "gun1": ["Pistol", None, 2],
    "gun2": ["None"],
    "gun3": ["None"]
    }
chance = []
for i in guns:
    if len(chance) == 0:
        if guns[i]["type"] != "heal":
            chance.append([i, guns[i]["chance"]])
        else:
            chance.append([i, guns[i]["chance"], guns[i]["amount"]])
    else:
        if guns[i]["type"] != "heal":
            chance.append([i, guns[i]["chance"] + chance[len(chance) - 1][1]])
        else:
            chance.append([i, guns[i]["chance"] + chance[len(chance) - 1][1], guns[i]["amount"]])
print(chance)
botspersecondchance = 2
character = pygame.transform.scale(pygame.image.load("character.png").convert_alpha(),(1000,1000))
def game():
    cooldown = 0
    openinventory = False
    playerp = [0.0, 0.0]
    speed = 200
    health = [100, 100]
    dmgprint = []
    gunpush = 0
    playerscale = 1
    money = 0
    healing = 0
    bots = []
    swing = {
        "active": False,"weapon": None,"time": 0,"angle": 0}
    bob = [False, 20]
    forwards = False
    bullets = []
    angle = 0
    changething = [False, 0]
    dead = False
    while dead == False:
        screen.fill((0,0,0))
        dt = clock.tick(150) / 1000
        if openinventory is True:
            button1 = pygame.draw.rect(screen,(50 if inventory["gun1"][0] == "None" else 100, 50 if inventory["gun1"][0] == "None" else 100, 50 if inventory["gun1"][0] == "None" else 100), (200,250,50,50))
            if inventory["gun1"][0] != "None":
                if changething[0] is False or changething[1] != 1:
                    screen.blit(pygame.transform.scale(guns[inventory["gun1"][0]]["appearence"],(90,45)), (200, 250))
                    pyprint((inventory["gun1"][0] if guns[inventory["gun1"][0]]["type"] != "heal" else f"{inventory["gun1"][2]} {inventory["gun1"][0]}{"s" if inventory["gun1"][2] != 1 else ""}"), 20, (255,255,255), (200, 200), None)
                else:
                    saa = pygame.Surface((80, 80), pygame.SRCALPHA)
                    saa.fill((255, 255, 255, 80))
                    screen.blit(saa, (200 - (changething[2][0] - changething[3][0]), 225 - (changething[2][1] - changething[3][1])))
                    screen.blit(pygame.transform.scale(guns[inventory["gun1"][0]]["appearence"],(90,45)), (200 - (changething[2][0] - changething[3][0]), 250 - (changething[2][1] - changething[3][1])))
                    pyprint((inventory["gun1"][0] if guns[inventory["gun1"][0]]["type"] != "heal" else f"{inventory["gun1"][2]} {inventory["gun1"][0]}{"s" if inventory["gun1"][2] != 1 else ""}"), 20, (255,255,255), (200 - (changething[2][0] - changething[3][0]), 200 - (changething[2][1] - changething[3][1])), None)
            button2 = pygame.draw.rect(screen,(50 if inventory["gun2"][0] == "None" else 100, 50 if inventory["gun2"][0] == "None" else 100, 50 if inventory["gun2"][0] == "None" else 100), (400,250,50,50))
            if inventory["gun2"][0] != "None":
                if changething[0] is False or changething[1] != 2:
                    screen.blit(pygame.transform.scale(guns[inventory["gun2"][0]]["appearence"],(90,45)), (400, 250))
                    pyprint((inventory["gun2"][0] if guns[inventory["gun2"][0]]["type"] != "heal" else f"{inventory["gun2"][2]} {inventory["gun2"][0]}{"s" if inventory["gun2"][2] != 1 else ""}"), 20, (255,255,255), (400, 200), None)
                else:
                    saa = pygame.Surface((80, 80), pygame.SRCALPHA)
                    saa.fill((255, 255, 255, 80))
                    screen.blit(saa, (400 - (changething[2][0] - changething[3][0]), 225 - (changething[2][1] - changething[3][1])))
                    screen.blit(pygame.transform.scale(guns[inventory["gun2"][0]]["appearence"],(90,45)), (400 - (changething[2][0] - changething[3][0]), 250 - (changething[2][1] - changething[3][1])))
                    pyprint((inventory["gun2"][0] if guns[inventory["gun2"][0]]["type"] != "heal" else f"{inventory["gun2"][2]} {inventory["gun2"][0]}{"s" if inventory["gun2"][2] != 1 else ""}"), 20, (255,255,255), (400 - (changething[2][0] - changething[3][0]), 200 - (changething[2][1] - changething[3][1])), None)
            button3 = pygame.draw.rect(screen,(50 if inventory["gun3"][0] == "None" else 100, 50 if inventory["gun3"][0] == "None" else 100, 50 if inventory["gun3"][0] == "None" else 100), (600,250,50,50))
            if inventory["gun3"][0] != "None":
                if changething[0] is False or changething[1] != 3:
                    screen.blit(pygame.transform.scale(guns[inventory["gun3"][0]]["appearence"],(90,45)), (600, 250))
                    pyprint((inventory["gun3"][0] if guns[inventory["gun3"][0]]["type"] != "heal" else f"{inventory["gun3"][2]} {inventory["gun3"][0]}{"s" if inventory["gun3"][2] != 1 else ""}"), 20, (255,255,255), (600, 200), None)
                else:
                    saa = pygame.Surface((80, 80), pygame.SRCALPHA)
                    saa.fill((255, 255, 255, 80))
                    screen.blit(saa, (600 - (changething[2][0] - changething[3][0]), 225 - (changething[2][1] - changething[3][1])))
                    screen.blit(pygame.transform.scale(guns[inventory["gun3"][0]]["appearence"],(90,45)), (600 - (changething[2][0] - changething[3][0]), 250 - (changething[2][1] - changething[3][1])))
                    pyprint((inventory["gun3"][0] if guns[inventory["gun3"][0]]["type"] != "heal" else f"{inventory["gun3"][2]} {inventory["gun3"][0]}{"s" if inventory["gun3"][2] != 1 else ""}"), 20, (255,255,255), (600 - (changething[2][0] - changething[3][0]), 200 - (changething[2][1] - changething[3][1])), None)
            mousepress = pygame.mouse.get_pressed()
            if mousepress[0] and changething[0]:
                changething[3] = pygame.mouse.get_pos()
            elif changething[0]:
                changething[0] = False
                if button1.collidepoint(changething[3]) and changething[1] != 1:
                    pastlol = inventory["gun1"]
                    inventory["gun1"] = inventory[f"gun{changething[1]}"]
                    inventory[f"gun{changething[1]}"] = pastlol
                    inventory["gun"] = "gun1"
                if button2.collidepoint(changething[3]) and changething[1] != 2:
                    pastlol = inventory["gun2"]
                    inventory["gun2"] = inventory[f"gun{changething[1]}"]
                    inventory[f"gun{changething[1]}"] = pastlol
                    inventory["gun"] = "gun2"
                if button3.collidepoint(changething[3]) and changething[1] != 3:
                    pastlol = inventory["gun3"]
                    inventory["gun3"] = inventory[f"gun{changething[1]}"]
                    inventory[f"gun{changething[1]}"] = pastlol
                    inventory["gun"] = "gun3"
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                    pygame.quit()
                if event.type == pygame.KEYDOWN:
                    if event.unicode == "e":
                        openinventory = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if (button1.collidepoint(event.pos) and inventory["gun1"][0] != "None"):
                        changething = [True, 1, pygame.mouse.get_pos(), [0,0]]
                    elif button2.collidepoint(event.pos) and inventory["gun2"][0] != "None":
                        changething = [True, 2, pygame.mouse.get_pos(), [0,0]]
                    elif (button3.collidepoint(event.pos) and inventory["gun3"][0] != "None"):
                        changething = [True, 3, pygame.mouse.get_pos(), [0,0]]
        else:
            frameshoot = 0
            cooldown += 1 * dt
            if health[1] <= 0:
                dead = True
            if swing["active"]:
                swing["time"] -= dt

                weapon = guns[swing["weapon"]]

                progress = 1 - (swing["time"] / weapon["speed"])

                # smooth swing from -range/2 to +range/2
                swing["angle"] = -((-weapon["swingrange"] / 2) + (weapon["swingrange"] * progress))
                if swing["time"] <= 0:
                    swing["active"] = False
                    swing["angle"] = 0
            if random.randint(1, int((1 / max(dt,0.00000001)) * botspersecondchance)) == 1:
                bots.append([[random.randint(int(playerp[0] - 300), int(playerp[0] + 300)), random.randint(int(playerp[1] - 300), int(playerp[1] + 300))], 100])
                while bots[len(bots) - 1][0][0] + 50 > playerp[0] - 80 and bots[len(bots) - 1][0][0] > playerp[0] + 100 and bots[len(bots) - 1][0][1] + 50 > playerp[0] - 80 and bots[len(bots) - 1][0][1] > playerp[0] + 100:
                    bots.pop(len(bots) - 1)
                    bots.append([[random.randint(int(playerp[0] - 300), int(playerp[0] + 300)), random.randint(int(playerp[1] - 300), int(playerp[1] + 300))], 100])
            camera = [playerp[0] - 400, playerp[1] - 300]
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if guns[inventory[inventory["gun"]][0]]["type"] not in ["heal"]:
                    frameshoot = 1 if event.type == pygame.MOUSEBUTTONDOWN and cooldown >= guns[inventory[inventory["gun"]][0]]["cooldown"] else 0
                if guns[inventory[inventory["gun"]][0]]["type"] == "heal":
                    healing = guns[inventory[inventory["gun"]][0]]["time"] if event.type == pygame.MOUSEBUTTONDOWN and healing == 0 and inventory[inventory["gun"]][2] > 0 else healing
                if event.type == pygame.KEYDOWN:
                    z = 0
                    z += 1 if inventory["gun1"][0] != "None" else 0
                    z += 1 if inventory["gun2"][0] != "None" else 0
                    z += 1 if inventory["gun3"][0] != "None" else 0
                    if event.unicode == "q" and z > 1:
                        inventory[inventory["gun"]] = ["None"]
                        if inventory["gun1"][0] != "None":
                            inventory["gun"] = "gun1"
                        elif inventory["gun2"][0] != "None":
                            inventory["gun"] = "gun2"
                        else:
                            inventory["gun"] = "gun3"
                    if event.unicode == "e":
                        openinventory = True
            keys = pygame.key.get_pressed()
            mouse = pygame.mouse.get_pressed()
            if guns[inventory[inventory["gun"]][0]]["type"] not in ["heal"]:
                frameshoot = 1 if mouse[0] and guns[inventory[inventory["gun"]][0]]["autoshoot"] == 1 and cooldown >= guns[inventory[inventory["gun"]][0]]["cooldown"] else frameshoot
            playerp[1] += speed * dt if keys[pygame.K_s] or keys[pygame.K_DOWN] else 0
            playerp[0] -= speed * dt if keys[pygame.K_a] or keys[pygame.K_LEFT] else 0
            playerp[1] -= speed * dt if keys[pygame.K_w] or keys[pygame.K_UP] else 0
            playerp[0] += speed * dt if keys[pygame.K_d] or keys[pygame.K_RIGHT] else 0
            inventory["gun"] = "gun1" if keys[pygame.K_1] and inventory["gun1"][0] != "None" else inventory["gun"]
            inventory["gun"] = "gun2" if keys[pygame.K_2] and inventory["gun2"][0] != "None" else inventory["gun"]
            inventory["gun"] = "gun3" if keys[pygame.K_3] and inventory["gun3"][0] != "None" else inventory["gun"]
            if forwards and inventory[inventory["gun"]][0] != "None":
                gunpush += guns[inventory[inventory["gun"]][0]]["pushback"] * dt * 10
                forwards = False if gunpush >= guns[inventory[inventory["gun"]][0]]["pushback"] else True
            elif inventory[inventory["gun"]][0] != "None" and guns[inventory[inventory["gun"]][0]]["type"] not in ["heal"]:
                gunpush -= guns[inventory[inventory["gun"]][0]]["pushback"] * dt * 2 * (gunpush / 5)
                gunpush = max(gunpush, 0)
            if healing > 0:
                if healing == guns[inventory[inventory["gun"]][0]]["time"]:
                    inventory[inventory["gun"]][2] -= 1
                healing -= 1 * dt
                mousepos = pygame.mouse.get_pos()
                pygame.draw.rect(screen, (70,70,70), (mousepos[0] - 10, mousepos[1] - 50, 50, 10))
                pygame.draw.rect(screen, (255,255,255), (mousepos[0] - 10, mousepos[1] - 50, 50 * (guns[inventory[inventory["gun"]][0]]["time"] - healing / guns[inventory[inventory["gun"]][0]]["time"]), 10))
                if healing <= 0:
                    healing = 0
                    health[1] = min(guns[inventory[inventory["gun"]][0]]["health"] + health[1], health[0])
            if frameshoot == 1 and inventory[inventory["gun"]][0] != "None":
                forwards = True
                mx, my = pygame.mouse.get_pos()
                mx, my = [mx + camera[0], my + camera[1]]
                dx = mx - playerp[0]
                dy = my - playerp[1]
                dist = max(math.sqrt(dx*dx + dy*dy), 1)
                dx /= dist
                dy /= dist
                cooldown = 0
                playerp[0] -= dx * guns[inventory[inventory["gun"]][0]]["personback"]
                playerp[1] -= dy * guns[inventory[inventory["gun"]][0]]["personback"]
                palsad = 0
                if guns[inventory[inventory["gun"]][0]]["type"] == "projectile":
                    while palsad < guns[inventory[inventory["gun"]][0]]["pelets"]:
                        palsad += 1
                        mx, my = [mx + random.randint((palsad // 2) * - guns[inventory[inventory["gun"]][0]]["pelet spread"], (palsad // 2) * guns[inventory[inventory["gun"]][0]]["pelet spread"]),
                                my + random.randint((palsad // 2) * -guns[inventory[inventory["gun"]][0]]["pelet spread"], (palsad // 2) * guns[inventory[inventory["gun"]][0]]["pelet spread"])]
                        dx = mx - playerp[0] - 0
                        dy = my - playerp[1] + 0
                        dist = max(math.sqrt(dx*dx + dy*dy), 1)
                        dx /= dist
                        dy /= dist
                        barrellength = 50

                        bulletx = gunx + math.cos(math.radians(angle)) * barrellength + camera[0]

                        bullety = guny - math.sin(math.radians(angle)) * barrellength + camera[1]
                        bullets.append([bulletx,bullety,dx,dy,inventory[inventory["gun"]][0]])
                elif guns[inventory[inventory["gun"]][0]]["type"] == "melee":
                    swing["active"] = True
                    swing["weapon"] = inventory[inventory["gun"]][0]
                    swing["time"] = guns[inventory[inventory["gun"]][0]]["speed"]
                    swing["start"] = angle
                    swing["hit"] = []
                # PLAYER CENTER ON SCREEN
            px = playerp[0] - camera[0] + 30
            py = playerp[1] - camera[1] + 30

            # MOUSE
            mx, my = pygame.mouse.get_pos()

            # AIM DIRECTION
            dx = mx - px
            dy = my - py

            # AIM ANGLE
            if swing["active"] is False:
                angle = math.degrees(math.atan2(-dy, dx))
            else:
                angle = swing["start"] + swing["angle"]

            # CURRENT WEAPON
            currentgun = guns[inventory[inventory["gun"]][0]]["appearence"]

            # ROTATE IMAGE
            rotatedgun = pygame.transform.rotate(currentgun, angle)

            # PROJECTILE GUNS
            if guns[inventory[inventory["gun"]][0]]["type"] == "projectile":

                gunoffset = 0

                gunx = px + math.cos(math.radians(angle)) * gunoffset
                guny = py - math.sin(math.radians(angle)) * gunoffset

                gunrect = rotatedgun.get_rect(center=(gunx, guny))

            # MELEE WEAPONS
            else:

                # hand location around player
                handradius = 40

                pivotx = px + math.cos(math.radians(angle)) * handradius
                pivoty = py - math.sin(math.radians(angle)) * handradius

                # move sword outward from handle
                handle_offset = 50

                gunx = pivotx + math.cos(math.radians(angle)) * handle_offset
                guny = pivoty - math.sin(math.radians(angle)) * handle_offset

                gunrect = rotatedgun.get_rect(center=(gunx, guny))
            scaledplayer = pygame.transform.scale(character,(int(64 * playerscale),int(64 * playerscale)))
            playerrect = scaledplayer.get_rect(center=(playerp[0] - camera[0] + 30,playerp[1] - camera[1] + 30 + bob[1]))
            screen.blit(scaledplayer, playerrect)
            screen.blit(rotatedgun, gunrect)
            for inde, bot in enumerate(bots):
                dx = bot[0][0] - playerp[0]
                dy = bot[0][1] - playerp[1]
                dist = max(math.sqrt(dx*dx + dy*dy), 1)
                dx /= dist
                dy /= dist
                bot[0][0] -= dx * dt * 50
                bot[0][1] -= dy * dt * 50
                botrect = pygame.Rect(bot[0][0] - camera[0],bot[0][1] - camera[1],50,50)
                for index, bullet in enumerate(bullets):
                    if bot[0][0] < bullet[0] + guns[bullet[4]]["size"] and bot[0][0] + 50 > bullet[0] and bot[0][1] < bullet[1] + guns[bullet[4]]["size"] and bot[0][1] + 50 > bullet[1]:
                        bot[1] -= guns[bullet[4]]["damage"]
                        dmgprint.append([guns[bullet[4]]["damage"], bot[0][0] - 50 + random.randint(-10, 10), bot[0][1] - 50 + random.randint(-10, 10), 0])
                        if len(bullets) >= index + 1:
                            bullets.pop(index)
                        if bot[1] <= 0 and len(bots) >= inde + 1:
                            bots.pop(inde)
                            ranran = random.randint(1, 1000) / 10
                            for index, chanc in enumerate(chance):
                                previous = chance[index - 1][1] if index > 0 else 0
                                if previous < ranran <= chanc[1] and chanc[0] not in [inventory["gun1"][0], inventory["gun2"][0], inventory["gun3"][0]]:
                                    if previous < ranran <= chanc[1] and chanc[0] not in [inventory["gun1"][0],inventory["gun2"][0],inventory["gun3"][0]]:
                                        droppedgun = [chanc[0]] if len(chanc) < 3 else [chanc[0], chanc[2]]
                                        if inventory["gun1"][0] == "None":
                                            inventory["gun1"] = [droppedgun[0], None, droppedgun[1]] if len(droppedgun) > 1 else [droppedgun[0], None]
                                        elif inventory["gun2"][0] == "None":
                                            inventory["gun2"] = [droppedgun[0], None, droppedgun[1]] if len(droppedgun) > 1 else [droppedgun[0], None]
                                        elif inventory["gun3"][0] == "None":
                                            inventory["gun3"] = [droppedgun[0], None, droppedgun[1]] if len(droppedgun) > 1 else [droppedgun[0], None]

                                        break
                if swing["active"]:
                    katanamask = pygame.mask.from_surface(rotatedgun)
                    botsurface = pygame.Surface((50, 50), pygame.SRCALPHA)
                    pygame.draw.rect(botsurface, (255,255,255), (0,0,50,50))
                    botmask = pygame.mask.from_surface(botsurface)
                    offset = (int(botrect.x - gunrect.x),int(botrect.y - gunrect.y))
                    if katanamask.overlap(botmask, offset):
                        if inde not in swing["hit"]:
                            swing["hit"].append(inde)
                            if  swing["weapon"] in ["Katana", "Claymore", "Giant Claymore"]:
                                aa = int(guns[swing["weapon"]]["damage"] / (guns[swing["weapon"]]["multiplier"][1] ** len(swing["hit"]) - 1)) if guns[swing["weapon"]]["multiplier"][0] == "ediv" else 0
                                aa = int(guns[swing["weapon"]]["damage"] * (guns[swing["weapon"]]["multiplier"][1] ** len(swing["hit"]) - 1)) if guns[swing["weapon"]]["multiplier"][0] == "emul" else aa
                                aa = int(guns[swing["weapon"]]["damage"] / (guns[swing["weapon"]]["multiplier"][1] * len(swing["hit"]) - 1)) if guns[swing["weapon"]]["multiplier"][0] == "div" else aa
                                aa = int(guns[swing["weapon"]]["damage"] * (guns[swing["weapon"]]["multiplier"][1] * len(swing["hit"]) - 1)) if guns[swing["weapon"]]["multiplier"][0] == "mult" else aa
                                bot[1] -= aa
                                dmgprint.append([aa, bot[0][0] - 50 + random.randint(-10, 10), bot[0][1] - 50 + random.randint(-10, 10), 0])
                            knockdx = math.cos(math.radians(angle))
                            knockdy = -math.sin(math.radians(angle))
                            bot[0][0] += knockdx * guns["Katana"]["knockback"]
                            bot[0][1] += knockdy * guns["Katana"]["knockback"]
                            
                            if bot[1] <= 0 and len(bots) >= inde + 1:
                                bots.pop(inde)
                                if swing["active"]:
                                    poping = []
                                    for index, illa in enumerate(swing["hit"]):
                                        if illa >= inde:
                                            swing["hit"][index] -= 1
                                            if swing["hit"][index] < 0:
                                                poping.append(index)
                                    (swing["hit"].pop(popin) for popin in poping)
                                ranran = random.randint(1, 100) / 10
                                for index, chanc in enumerate(chance):
                                    previous = chance[index - 1][1] if index > 0 else 0
                                    if previous < ranran <= chanc[1] and chanc[0] not in [inventory["gun1"][0],inventory["gun2"][0],inventory["gun3"][0]]:
                                        droppedgun = [chanc[0]] if len(chanc) < 3 else [chanc[0], chanc[2]]
                                        if inventory["gun1"][0] == "None":
                                            inventory["gun1"] = [droppedgun[0], None, droppedgun[1]] if len(droppedgun) > 1 else [droppedgun[0], None]
                                        elif inventory["gun2"][0] == "None":
                                            inventory["gun2"] = [droppedgun[0], None, droppedgun[1]] if len(droppedgun) > 1 else [droppedgun[0], None]
                                        elif inventory["gun3"][0] == "None":
                                            inventory["gun3"] = [droppedgun[0], None, droppedgun[1]] if len(droppedgun) > 1 else [droppedgun[0], None]

                                        break
                if bot[0][0] + bot[1]/2.5 + 20 > playerp[0] and bot[0][0] < playerp[0] + 50 and bot[0][1] + bot[1]/2.5 + 20 > playerp[1] and bot[0][1] < playerp[1] + bot[1]/2.5 + 20:
                    health[1] -= 25 * dt
                botsdafa = pygame.draw.rect(screen,(255,0,0), (bot[0][0] - camera[0],bot[0][1] - camera[1],bot[1]/2.5 + 20,bot[1]/2.5 + 20))
            for i in bullets:
                i[0] += i[2] * guns[i[4]]["speed"] * dt
                i[1] += i[3] * guns[i[4]]["speed"] * dt
                pygame.draw.rect(screen, (255, 0, 0), (i[0] - camera[0] - 25, i[1] - camera[1] - 25, guns[i[4]]["size"], guns[i[4]]["size"]))
            if bob[0] is True:
                bob[1] += 20 * dt 
            else:
                bob[1] -= 20 * dt
            bob[0] = not bob[0] if (bob[1] >= 10 and bob[0] is True) or (bob[1] <= 0 and bob[0] is False) else bob[0]
            for index, printed in enumerate(dmgprint):
                dmgprint[index][2] -= 4 / max(printed[3], 0.001) * dt
                apyprint(f"{printed[0]}", 20, (255,255,255), (printed[1] - camera[0], int(printed[2] - camera[1])), None, int((250 - 250 / (1 / max(0.0001, printed[3])))))
                if len(dmgprint) >= index + 1:
                    dmgprint[index][3] += dt
                if printed[3] >= 1 and len(dmgprint) >= index + 1:
                    dmgprint.pop(index)
            health[1] = max(health[1], 0)
            pyprint(f"{int(health[1])} / {int(health[0])}  money: {money}$", 20, (0,255,0), (300, 0), None)
            pygame.draw.rect(screen, (60, 60, 60), (200,20,300,5))
            pygame.draw.rect(screen, (0,255,0), (200, 20,health[1] / health[0] * 300,5))
            pygame.draw.rect(screen,(0,0,255),(1-camera[0],1-camera[1],10,10))
            pyprint(inventory["gun1"][0], 20, ((255, 255, 255) if inventory["gun"] == "gun1" else (200, 200, 200)), (200, 550), None) if inventory["gun1"][0] != "None" else 0
            pyprint(inventory["gun2"][0], 20, ((255, 255, 255) if inventory["gun"] == "gun2" else (200, 200, 200)), (400, 550), None) if inventory["gun2"][0] != "None" else 0
            pyprint(inventory["gun3"][0], 20, ((255, 255, 255) if inventory["gun"] == "gun3" else (200, 200, 200)), (600, 550), None) if inventory["gun3"][0] != "None" else 0
        pygame.display.flip()
game()